# J.A.R.V.I.S. — Chromebook Edition

An original, lightweight, local-first assistant interface designed with low-resource Chromebooks in mind.

## Current build
- Responsive dashboard with animated CSS orb and navigation.
- Camera preview with explicit activation and stop controls.
- Browser text-to-speech with English voice preference and language selection.
- Push-to-talk speech recognition when the browser supports it.
- Local demo chat with clearly labelled demo responses.
- Optional secure backend proxy scaffold for cloud AI.
- PWA manifest and offline app-shell service worker.

## Quick start
A PWA requires HTTPS or localhost. Do not open `index.html` using `file://`.

```bash
cd jarvis-chromebook
python3 -m http.server 8000
```
Open `http://localhost:8000` for a basic UI test. For installation on ChromeOS, deploy the static project to an HTTPS host (GitHub Pages is suitable), open it in Chrome, then use Chrome menu → **Install app** or **Create shortcut** if offered.

## Cloud AI
See `backend/README.md`. The browser's Settings → Cloud AI endpoint should point to your deployed backend's `/api/chat` route. Keep provider keys only in backend environment variables.

## Important limits
A PWA cannot take unrestricted control of ChromeOS, type into arbitrary applications, or run a dependable always-on wake-word listener in the background. The included push-to-talk option depends on browser support and may require network access. Offline mode covers the cached app shell and local demo responses, not cloud AI.

## Files
See `docs/ARCHITECTURE.md`, `docs/INSTALLATION.md`, and `docs/TROUBLESHOOTING.md`.
