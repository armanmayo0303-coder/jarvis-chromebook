import { startCamera, stopCamera } from "./modules/camera.js";
import { speak, stopSpeaking, listenOnce, speechSupport } from "./modules/voice.js";
import { sendChat } from "./modules/chat.js";
import { loadSettings, saveSettings, readSettings } from "./modules/settings.js";

const $ = id => document.getElementById(id);
let deferredInstall = null;
let sessionStarted = false;

function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),2600)}
function setOrb(state){$("orbCaption").textContent=state.toUpperCase();$("orbGlyph").textContent=state==="error"?"!":"J";$("orbGlyph").closest(".orb-wrap").className="orb-wrap "+state}
function setStatus(text){$("systemStatus").textContent=text.toUpperCase()}
function showDashboard(){ $("welcome").classList.add("hidden");$("dashboard").classList.remove("hidden");sessionStarted=true;setStatus("SYSTEM ONLINE");setOrb("standby"); }
function switchView(name){document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));$("view-"+name).classList.remove("hidden");document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view===name));}
function addMessage(text,who="assistant",tag="JARVIS // DEMO"){const box=document.createElement("div");box.className="message "+who;const label=document.createElement("span");label.className="msg-tag";label.textContent=who==="user"?"YOU":tag;const p=document.createElement("p");p.textContent=text;box.append(label,p);$("chatLog").append(box);$("chatLog").scrollTop=$("chatLog").scrollHeight;return box}
async function handleChat(){const input=$("chatInput"),message=input.value.trim();if(!message)return;input.value="";addMessage(message,"user");setOrb("thinking");const pending=addMessage("Processing…","assistant");try{const result=await sendChat(message,readSettings());pending.remove();addMessage(result.text,"assistant",result.mode==="cloud"?"JARVIS // CLOUD AI":"JARVIS // LOCAL DEMO");if(result.action)toast(result.action);setOrb("speaking");speak(result.text,readSettings()).finally(()=>setOrb("standby"));}catch(e){pending.remove();addMessage("I could not complete that request. "+e.message);setOrb("error");}}
$("startBtn").addEventListener("click",()=>{showDashboard();toast("Core interface initialized.");});
$("continueBtn").addEventListener("click",()=>{showDashboard();toast("Session resumed.");});
$("settingsTop").addEventListener("click",()=>{if(!sessionStarted)showDashboard();switchView("settings")});
document.querySelectorAll(".nav-btn").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
$("sendBtn").addEventListener("click",handleChat);$("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter")handleChat()});
$("clearChat").addEventListener("click",()=>{$("chatLog").replaceChildren();addMessage("Conversation cleared. How may I help?");});
$("cameraStart").addEventListener("click",async()=>{try{await startCamera($("cameraPreview"),readSettings().cameraResolution);$("cameraPlaceholder").classList.add("hidden");$("cameraStatus").textContent="ACTIVE";$("cameraStart").disabled=true;$("cameraStop").disabled=false;toast("Camera active. Video remains on this device.");}catch(e){toast("Camera unavailable: "+e.message);$("cameraStatus").textContent="ERROR";}});
$("cameraStop").addEventListener("click",()=>{stopCamera($("cameraPreview"));$("cameraPlaceholder").classList.remove("hidden");$("cameraStatus").textContent="OFFLINE";$("cameraStart").disabled=false;$("cameraStop").disabled=true;});
$("speakTest").addEventListener("click",()=>{setOrb("speaking");speak("Hello. I am JARVIS. Your English voice interface is ready.",readSettings()).finally(()=>setOrb("standby"));$("voiceStatus").textContent="SPEAKING";});
$("stopSpeech").addEventListener("click",()=>{stopSpeaking();$("voiceStatus").textContent="STANDBY";setOrb("standby")});
$("listenBtn").addEventListener("click",async()=>{if(!speechSupport()){toast("Speech recognition is not supported in this browser. Use text input.");return;}try{$("voiceStatus").textContent="LISTENING";setOrb("listening");const phrase=await listenOnce(readSettings().language);$("chatInput").value=phrase;setOrb("standby");$("voiceStatus").textContent="STANDBY";toast("Speech captured. Review and press Send.");}catch(e){setOrb("standby");$("voiceStatus").textContent="STANDBY";toast(e.message);}});
$("saveSettings").addEventListener("click",()=>{saveSettings(readSettings());toast("Settings saved on this device.");});
$("speechRate").addEventListener("input",e=>$("rateValue").textContent=Number(e.target.value).toFixed(1)+"×");
$("installBtn").addEventListener("click",async()=>{if(deferredInstall){deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;}else toast("In Chrome, use ⋮ menu → Install app (when available).");});
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;});
window.addEventListener("beforeunload",()=>stopCamera($("cameraPreview")));
function updateNetwork(){$("networkStatus").textContent=navigator.onLine?"NETWORK AVAILABLE":"OFFLINE MODE";}
window.addEventListener("online",updateNetwork);window.addEventListener("offline",updateNetwork);updateNetwork();
function tick(){$("clock").textContent=new Intl.DateTimeFormat(undefined,{hour:"2-digit",minute:"2-digit"}).format(new Date());}tick();setInterval(tick,30000);
loadSettings();$("speechSupport").textContent=speechSupport()?"Speech recognition available (may require network).":"Speech recognition unavailable; use typing.";
if("serviceWorker" in navigator && location.protocol!=="file:"){navigator.serviceWorker.register("./service-worker.js").catch(()=>{});}
if(!navigator.mediaDevices?.getUserMedia){$("cameraStart").disabled=true;$("cameraStatus").textContent="UNSUPPORTED";}
